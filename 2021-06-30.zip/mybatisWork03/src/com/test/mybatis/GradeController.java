package com.test.mybatis;

public class GradeController
{

}
