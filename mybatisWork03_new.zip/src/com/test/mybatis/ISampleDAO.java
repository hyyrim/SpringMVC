/*=================
 * ISampleDAO.java
 * - 인터페이스
==================*/
package com.test.mybatis;

public interface ISampleDAO
{

}
